#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Home.tsx更新器：将爬虫数据直接映射到Home.tsx的games数组中
"""

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HomeTsxUpdater:
    """Home.tsx更新器"""
    
    def __init__(self, home_tsx_path: str = "../src/pages/Home.tsx"):
        self.home_tsx_path = Path(home_tsx_path)
        self.backup_path = self.home_tsx_path.with_suffix('.tsx.backup')
    
    def load_scraped_data(self, filename: str) -> List[Dict[str, Any]]:
        """加载爬虫数据"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 处理不同的数据格式
            if isinstance(data, dict):
                games = data.get('games', [])
            elif isinstance(data, list):
                games = data
            else:
                logger.error(f"未知的数据格式: {type(data)}")
                return []
            
            logger.info(f"成功加载爬虫数据: {len(games)} 个游戏")
            return games
        except Exception as e:
            logger.error(f"加载爬虫数据失败: {e}")
            return []
    
    def convert_to_home_format(self, scraped_games: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """将爬虫数据转换为Home.tsx格式"""
        home_games = []
        
        for i, game in enumerate(scraped_games):
            # 提取基本信息
            title = game.get('title', f'Game {i+1}')
            image = game.get('cover_image', game.get('image', ''))
            url = game.get('game_url', game.get('url', ''))
            iframe_url = game.get('iframe_url', '')
            description = game.get('description', 'A fun and exciting online game!')
            category = game.get('category', '其他')
            
            # 处理封面图片URL
            if image and not image.startswith('http'):
                if image.startswith('/'):
                    image = f"https://www.crazygames.com{image}"
                else:
                    image = f"https://imgs.crazygames.com/{image}"
            
            # 确保封面URL包含完整参数
            if image and 'imgs.crazygames.com' in image and 'cover' in image:
                if '?' not in image:
                    image += '?metadata=none&quality=85&width=273&fit=crop'
            
            # 生成iframe HTML
            if iframe_url:
                iframe_html = f'<iframe src="{iframe_url}" style="width: 100%; height: 100%;" frameborder="0" allow="gamepad *;"></iframe>'
            else:
                # 从URL生成默认iframe
                if 'crazygames.com/game/' in url:
                    game_slug = url.split('/game/')[-1].split('?')[0].split('#')[0]
                    iframe_url = f"https://games.crazygames.com/en_US/{game_slug}/index.html"
                    iframe_html = f'<iframe src="{iframe_url}" style="width: 100%; height: 100%;" frameborder="0" allow="gamepad *;"></iframe>'
                else:
                    iframe_html = '<iframe src="about:blank" style="width: 100%; height: 100%;" frameborder="0"></iframe>'
            
            # 生成控制说明
            controls = self._generate_controls(category, title)
            
            # 生成特性列表
            features = game.get('features', [])
            if not features:
                features = self._generate_features(category, title)
            
            # 创建Home.tsx格式的游戏对象
            home_game = {
                'id': i + 1,
                'title': title,
                'image': image,
                'description': self._truncate_description(description),
                'features': features,
                'isNew': game.get('is_new', False),
                'iframe': iframe_html,
                'controls': controls,
                'category': self._map_category(category),
                'playCount': game.get('play_count', 0),
                'likes': game.get('likes', 0),
                'favorites': game.get('favorites', 0),
                'duration': game.get('duration', '5-10 分钟')
            }
            
            home_games.append(home_game)
        
        logger.info(f"成功转换 {len(home_games)} 个游戏到Home.tsx格式")
        return home_games
    
    def _generate_controls(self, category: str, title: str) -> List[Dict[str, str]]:
        """生成游戏控制说明"""
        title_lower = title.lower()
        
        if any(word in title_lower for word in ['racing', 'car', 'race', 'drive']):
            return [
                {'key': 'Arrow Keys', 'action': 'STEER'},
                {'key': 'Space', 'action': 'BRAKE'},
                {'key': 'Shift', 'action': 'NITRO'}
            ]
        elif any(word in title_lower for word in ['shoot', 'gun', 'battle', 'war']):
            return [
                {'key': 'Mouse', 'action': 'AIM'},
                {'key': 'Left Click', 'action': 'SHOOT'},
                {'key': 'WASD', 'action': 'MOVE'}
            ]
        elif any(word in title_lower for word in ['puzzle', 'match', 'connect']):
            return [
                {'key': 'Mouse', 'action': 'SELECT'},
                {'key': 'Click', 'action': 'PLACE'},
                {'key': 'Drag', 'action': 'MOVE'}
            ]
        elif any(word in title_lower for word in ['idle', 'tycoon', 'management']):
            return [
                {'key': 'Mouse', 'action': 'MANAGE'},
                {'key': 'Click', 'action': 'UPGRADE'},
                {'key': 'Scroll', 'action': 'NAVIGATE'}
            ]
        else:
            return [
                {'key': 'Mouse', 'action': 'INTERACT'},
                {'key': 'Click', 'action': 'PLAY'},
                {'key': 'Arrow Keys', 'action': 'MOVE'}
            ]
    
    def _generate_features(self, category: str, title: str) -> List[str]:
        """生成游戏特性列表"""
        title_lower = title.lower()
        features = ['在线游戏', '免费游戏']
        
        if any(word in title_lower for word in ['multiplayer', 'multi', 'battle']):
            features.append('多人游戏')
        if any(word in title_lower for word in ['3d', '3D']):
            features.append('3D图形')
        if any(word in title_lower for word in ['idle', 'tycoon']):
            features.append('放置游戏')
        if any(word in title_lower for word in ['puzzle', 'brain']):
            features.append('益智游戏')
        if any(word in title_lower for word in ['racing', 'car']):
            features.append('竞速游戏')
        
        return features
    
    def _map_category(self, category: str) -> str:
        """映射分类到Home.tsx格式"""
        category_mapping = {
            'Racing': 'racing',
            'Action': 'action',
            'Adventure': 'adventure',
            'Puzzle': 'puzzle',
            'Strategy': 'strategy',
            'Simulation': 'simulation',
            'Sports': 'sports',
            'Fighting': 'fighting',
            'Shooting': 'shooting',
            '其他': 'other'
        }
        return category_mapping.get(category, 'other')
    
    def _truncate_description(self, description: str, max_length: int = 100) -> str:
        """截断描述文本"""
        if not description:
            return 'A fun and exciting online game!'
        
        if len(description) <= max_length:
            return description
        
        # 在最后一个完整单词处截断
        truncated = description[:max_length]
        last_space = truncated.rfind(' ')
        if last_space > max_length * 0.8:  # 如果截断点不太远
            truncated = truncated[:last_space]
        
        return truncated + '...'
    
    def load_home_tsx(self) -> str:
        """加载Home.tsx文件内容"""
        try:
            with open(self.home_tsx_path, 'r', encoding='utf-8') as f:
                content = f.read()
            logger.info("成功加载Home.tsx文件")
            return content
        except Exception as e:
            logger.error(f"加载Home.tsx文件失败: {e}")
            return ""
    
    def create_backup(self, content: str) -> bool:
        """创建备份文件"""
        try:
            with open(self.backup_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info(f"已创建备份文件: {self.backup_path}")
            return True
        except Exception as e:
            logger.error(f"创建备份文件失败: {e}")
            return False
    
    def update_games_array(self, content: str, games: List[Dict[str, Any]]) -> str:
        """更新Home.tsx中的games数组"""
        try:
            # 生成新的games数组代码
            games_code = self._generate_games_code(games)
            
            # 查找并替换games数组
            pattern = r'const\s+games\s*:\s*Game\[\]\s*=\s*\[.*?\];'
            replacement = f'const games: Game[] = {games_code};'
            
            new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
            
            if new_content != content:
                logger.info("成功更新games数组")
                return new_content
            else:
                # 尝试其他模式
                pattern2 = r'const\s+games\s*=\s*\[.*?\];'
                replacement2 = f'const games = {games_code};'
                new_content = re.sub(pattern2, replacement2, content, flags=re.DOTALL)
                
                if new_content != content:
                    logger.info("成功更新games数组（模式2）")
                    return new_content
                else:
                    logger.warning("未找到games数组，尝试插入")
                    return self._insert_games_array(content, games_code)
                
        except Exception as e:
            logger.error(f"更新games数组失败: {e}")
            return content
    
    def _generate_games_code(self, games: List[Dict[str, Any]]) -> str:
        """生成games数组的TypeScript代码"""
        games_items = []
        
        for game in games:
            # 处理字符串转义
            title = game.get('title', '').replace("'", "\\'").replace('"', '\\"')
            description = game.get('description', '').replace("'", "\\'").replace('"', '\\"')
            image = game.get('image', '').replace("'", "\\'").replace('"', '\\"')
            iframe = game.get('iframe', '').replace("'", "\\'").replace('"', '\\"')
            
            # 处理数组
            features = json.dumps(game.get('features', []), ensure_ascii=False)
            controls = json.dumps(game.get('controls', []), ensure_ascii=False)
            
            game_item = f"""  {{
    id: {game.get('id', 0)},
    title: "{title}",
    image: "{image}",
    description: "{description}",
    features: {features},
    isNew: {str(game.get('isNew', False)).lower()},
    iframe: `{iframe}`,
    controls: {controls},
    category: "{game.get('category', 'other')}",
    playCount: {game.get('playCount', 0)},
    likes: {game.get('likes', 0)},
    favorites: {game.get('favorites', 0)},
    duration: "{game.get('duration', '5-10 分钟')}"
  }}"""
            
            games_items.append(game_item)
        
        return f"[\n{',\n'.join(games_items)}\n]"
    
    def _insert_games_array(self, content: str, games_code: str) -> str:
        """在文件中插入games数组"""
        # 查找合适的位置插入games数组
        insert_patterns = [
            r'(import.*?from.*?;\s*\n)',
            r'(interface\s+Game\s*\{.*?\}\s*\n)',
            r'(const.*?=.*?;\s*\n)'
        ]
        
        for pattern in insert_patterns:
            match = re.search(pattern, content, re.DOTALL)
            if match:
                insert_pos = match.end()
                new_content = content[:insert_pos] + f'\nconst games: Game[] = {games_code};\n\n' + content[insert_pos:]
                logger.info("成功插入games数组")
                return new_content
        
        logger.error("无法找到合适的插入位置")
        return content
    
    def save_home_tsx(self, content: str) -> bool:
        """保存更新后的Home.tsx文件"""
        try:
            with open(self.home_tsx_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info("成功保存Home.tsx文件")
            return True
        except Exception as e:
            logger.error(f"保存Home.tsx文件失败: {e}")
            return False
    
    def update_home_with_scraped_data(self, scraped_data_file: str) -> bool:
        """使用爬虫数据更新Home.tsx"""
        try:
            logger.info("开始使用爬虫数据更新Home.tsx...")
            
            # 1. 加载爬虫数据
            scraped_games = self.load_scraped_data(scraped_data_file)
            if not scraped_games:
                logger.error("无法加载爬虫数据")
                return False
            
            # 2. 转换为Home.tsx格式
            home_games = self.convert_to_home_format(scraped_games)
            if not home_games:
                logger.error("数据转换失败")
                return False
            
            # 3. 加载Home.tsx
            home_content = self.load_home_tsx()
            if not home_content:
                logger.error("无法加载Home.tsx文件")
                return False
            
            # 4. 创建备份
            if not self.create_backup(home_content):
                logger.warning("备份创建失败，但继续执行")
            
            # 5. 更新games数组
            updated_content = self.update_games_array(home_content, home_games)
            
            # 6. 保存文件
            if self.save_home_tsx(updated_content):
                logger.info("✅ Home.tsx更新完成！")
                logger.info(f"📊 更新了 {len(home_games)} 个游戏")
                return True
            else:
                logger.error("❌ Home.tsx更新失败！")
                return False
                
        except Exception as e:
            logger.error(f"更新Home.tsx过程中出错: {e}")
            return False

def main():
    """主函数"""
    import sys
    
    if len(sys.argv) < 2:
        print("用法: python home_tsx_updater.py <scraped_data_file>")
        print("示例: python home_tsx_updater.py enhanced_working_games_20250907_234146.json")
        sys.exit(1)
    
    scraped_data_file = sys.argv[1]
    updater = HomeTsxUpdater()
    
    # 执行更新
    success = updater.update_home_with_scraped_data(scraped_data_file)
    
    if success:
        print("🎉 Home.tsx更新成功完成！")
        print("📁 备份文件已保存")
        print("🔄 Home.tsx已更新")
    else:
        print("❌ Home.tsx更新失败，请检查日志")

if __name__ == "__main__":
    main()
