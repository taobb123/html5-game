#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一键运行脚本：执行完整的两步式爬虫流程
"""

import sys
import logging
import argparse
from pathlib import Path

# 导入各个模块
from step1_homepage_scraper import HomepageScraper
from step2_detail_scraper import DetailScraper
from integrate_data import DataIntegrator
from demo_data_generator import DemoDataGenerator
from home_tsx_updater import HomeTsxUpdater

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scraper.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ScraperRunner:
    """爬虫运行器"""
    
    def __init__(self):
        self.step1_scraper = HomepageScraper()
        self.step2_scraper = DetailScraper(max_workers=5)
        self.integrator = DataIntegrator()
        self.demo_generator = DemoDataGenerator()
        self.home_updater = HomeTsxUpdater()
    
    def run_demo_mode(self, count: int = 20) -> bool:
        """运行演示模式"""
        logger.info("🎭 运行演示模式...")
        
        try:
            # 生成演示数据
            if not self.demo_generator.generate_all_demo_data(count):
                logger.error("演示数据生成失败")
                return False
            
            # 测试数据集成
            logger.info("测试数据集成...")
            if self.integrator.integrate_data():
                logger.info("✅ 演示模式运行成功！")
                return True
            else:
                logger.error("❌ 数据集成失败")
                return False
                
        except Exception as e:
            logger.error(f"演示模式运行失败: {e}")
            return False
    
    def run_real_mode(self, max_games: int = 20) -> bool:
        """运行真实爬虫模式"""
        logger.info("🚀 运行真实爬虫模式...")
        
        try:
            # 第一步：爬取主页
            logger.info("第一步：爬取主页游戏信息...")
            step1_games = self.step1_scraper.scrape_homepage(max_games)
            
            if not step1_games:
                logger.error("第一步爬取失败，未获取到任何游戏")
                return False
            
            # 保存第一步数据
            if not self.step1_scraper.save_to_json(step1_games):
                logger.error("第一步数据保存失败")
                return False
            
            logger.info(f"✅ 第一步完成：获取 {len(step1_games)} 个游戏")
            
            # 第二步：爬取详情页
            logger.info("第二步：爬取游戏详细信息...")
            game_urls = [game.url for game in step1_games]
            step2_games = self.step2_scraper.scrape_game_details(game_urls)
            
            if not step2_games:
                logger.error("第二步爬取失败，未获取到任何详细信息")
                return False
            
            # 保存第二步数据
            if not self.step2_scraper.save_to_json(step2_games):
                logger.error("第二步数据保存失败")
                return False
            
            logger.info(f"✅ 第二步完成：获取 {len(step2_games)} 个游戏的详细信息")
            
            # 第三步：数据集成
            logger.info("第三步：数据集成到Home.tsx...")
            if self.integrator.integrate_data():
                logger.info("✅ 第三步完成：数据集成成功")
                return True
            else:
                logger.error("❌ 第三步失败：数据集成失败")
                return False
                
        except Exception as e:
            logger.error(f"真实爬虫模式运行失败: {e}")
            return False
    
    def run_step1_only(self, max_games: int = 20) -> bool:
        """只运行第一步"""
        logger.info("第一步：爬取主页游戏信息...")
        
        try:
            games = self.step1_scraper.scrape_homepage(max_games)
            
            if games:
                if self.step1_scraper.save_to_json(games):
                    logger.info(f"✅ 第一步完成：获取 {len(games)} 个游戏")
                    return True
                else:
                    logger.error("数据保存失败")
                    return False
            else:
                logger.error("未获取到任何游戏数据")
                return False
                
        except Exception as e:
            logger.error(f"第一步运行失败: {e}")
            return False
    
    def run_step2_only(self) -> bool:
        """只运行第二步"""
        logger.info("第二步：爬取游戏详细信息...")
        
        try:
            # 从第一步结果中读取URL
            import json
            with open('step1_homepage_games.json', 'r', encoding='utf-8') as f:
                step1_data = json.load(f)
            
            game_urls = [game['url'] for game in step1_data.get('games', [])]
            
            if not game_urls:
                logger.error("未找到第一步的结果文件或游戏URL")
                return False
            
            games = self.step2_scraper.scrape_game_details(game_urls)
            
            if games:
                if self.step2_scraper.save_to_json(games):
                    logger.info(f"✅ 第二步完成：获取 {len(games)} 个游戏的详细信息")
                    return True
                else:
                    logger.error("数据保存失败")
                    return False
            else:
                logger.error("未获取到任何详细信息")
                return False
                
        except Exception as e:
            logger.error(f"第二步运行失败: {e}")
            return False
    
    def run_integration_only(self) -> bool:
        """只运行数据集成"""
        logger.info("数据集成：更新Home.tsx...")
        
        try:
            if self.integrator.integrate_data():
                logger.info("✅ 数据集成完成")
                return True
            else:
                logger.error("❌ 数据集成失败")
                return False
                
        except Exception as e:
            logger.error(f"数据集成失败: {e}")
            return False
    
    def run_direct_home_update(self, scraped_data_file: str) -> bool:
        """直接使用爬虫数据更新Home.tsx"""
        logger.info("🚀 直接更新Home.tsx...")
        
        try:
            if self.home_updater.update_home_with_scraped_data(scraped_data_file):
                logger.info("✅ Home.tsx直接更新完成")
                return True
            else:
                logger.error("❌ Home.tsx直接更新失败")
                return False
                
        except Exception as e:
            logger.error(f"Home.tsx直接更新失败: {e}")
            return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='两步式爬虫运行器')
    parser.add_argument('--mode', choices=['demo', 'real', 'step1', 'step2', 'integrate', 'update-home'], 
                       default='demo', help='运行模式')
    parser.add_argument('--count', type=int, default=20, help='游戏数量（仅对demo和real模式有效）')
    parser.add_argument('--data-file', type=str, help='爬虫数据文件（仅对update-home模式有效）')
    
    args = parser.parse_args()
    
    runner = ScraperRunner()
    
    print("🎮 两步式爬虫系统")
    print("=" * 50)
    
    success = False
    
    if args.mode == 'demo':
        success = runner.run_demo_mode(args.count)
    elif args.mode == 'real':
        success = runner.run_real_mode(args.count)
    elif args.mode == 'step1':
        success = runner.run_step1_only(args.count)
    elif args.mode == 'step2':
        success = runner.run_step2_only()
    elif args.mode == 'integrate':
        success = runner.run_integration_only()
    elif args.mode == 'update-home':
        if not args.data_file:
            print("❌ 错误：update-home模式需要指定 --data-file 参数")
            print("示例: python run_scraper.py --mode update-home --data-file enhanced_working_games_20250907_234146.json")
            sys.exit(1)
        success = runner.run_direct_home_update(args.data_file)
    
    if success:
        print("\n🎉 运行成功！")
        print("📁 检查生成的文件：")
        if args.mode == 'update-home':
            print("   - Home.tsx (已更新)")
            print("   - Home.tsx.backup (备份文件)")
        else:
            print("   - step1_homepage_games.json (第一步数据)")
            print("   - step2_detailed_games.json (第二步数据)")
            print("   - merged_demo_data.json (合并数据)")
        print("   - scraper.log (运行日志)")
    else:
        print("\n❌ 运行失败！")
        print("📋 请检查 scraper.log 文件查看详细错误信息")
        sys.exit(1)

if __name__ == "__main__":
    main()

