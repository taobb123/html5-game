#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试真实爬取：测试从CrazyGames主页获取真实的游戏封面图片
"""

import logging
from step1_homepage_scraper import HomepageScraper

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_real_scraping():
    """测试真实爬取"""
    logger.info("🧪 开始测试真实爬取...")
    
    try:
        # 创建爬虫实例
        scraper = HomepageScraper()
        
        # 爬取主页（只爬取5个游戏进行测试）
        games = scraper.scrape_homepage(max_games=5)
        
        if games:
            logger.info(f"✅ 成功爬取 {len(games)} 个游戏")
            
            # 显示每个游戏的详细信息
            for i, game in enumerate(games, 1):
                logger.info(f"\n游戏 {i}:")
                logger.info(f"  标题: {game.title}")
                logger.info(f"  URL: {game.url}")
                logger.info(f"  分类: {game.category}")
                logger.info(f"  图片: {game.image}")
                
                # 检查图片URL是否有效
                if game.image:
                    if 'crazygames.com' in game.image or 'imgs.crazygames.com' in game.image:
                        logger.info(f"  ✅ 图片URL有效: {game.image}")
                    else:
                        logger.warning(f"  ⚠️ 图片URL可能无效: {game.image}")
                else:
                    logger.warning(f"  ❌ 未获取到图片")
            
            # 保存测试结果
            scraper.save_to_json(games, "test_real_games.json")
            logger.info("📁 测试结果已保存到 test_real_games.json")
            
        else:
            logger.error("❌ 未获取到任何游戏数据")
            
    except Exception as e:
        logger.error(f"测试过程中出错: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_real_scraping()

