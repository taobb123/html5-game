#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试数据集成脚本
"""

import json
import logging
from pathlib import Path

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_data_integration():
    """测试数据集成结果"""
    logger.info("🧪 开始测试数据集成...")
    
    try:
        # 检查生成的文件
        files_to_check = [
            'step1_homepage_games.json',
            'step2_detailed_games.json',
            'merged_demo_data.json'
        ]
        
        for filename in files_to_check:
            if Path(filename).exists():
                with open(filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                logger.info(f"✅ {filename}: {data.get('total_count', 0)} 个游戏")
            else:
                logger.error(f"❌ {filename}: 文件不存在")
        
        # 检查Home.tsx更新
        home_tsx_path = Path("../src/pages/Home.tsx")
        if home_tsx_path.exists():
            with open(home_tsx_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 检查是否包含games数组
            if 'const games = [' in content:
                logger.info("✅ Home.tsx: games数组已更新")
                
                # 统计游戏数量
                games_count = content.count('id:')
                logger.info(f"📊 Home.tsx: 包含 {games_count} 个游戏")
            else:
                logger.error("❌ Home.tsx: 未找到games数组")
        else:
            logger.error("❌ Home.tsx: 文件不存在")
        
        # 检查备份文件
        backup_path = Path("../src/pages/Home.tsx.backup")
        if backup_path.exists():
            logger.info("✅ 备份文件已创建")
        else:
            logger.warning("⚠️ 备份文件未找到")
        
        logger.info("🎉 数据集成测试完成！")
        
    except Exception as e:
        logger.error(f"测试过程中出错: {e}")

if __name__ == "__main__":
    test_data_integration()

