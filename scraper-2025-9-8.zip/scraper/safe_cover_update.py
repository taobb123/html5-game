#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
安全封面更新：只更新封面图，不破坏任何结构
"""

import json
import re

def update_covers_only():
    """只更新封面图，其他什么都不动"""
    
    # 读取爬虫数据
    with open('step1_homepage_games.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 读取Home.tsx
    with open('../src/pages/Home.tsx', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 只更新前3个游戏的封面图
    for i, game in enumerate(data['games'][:3]):
        old_image = f'image: "/[^"]*"'
        new_image = f'image: "{game["image"]}"'
        
        # 找到第i+1个游戏的image字段并替换
        pattern = f'id: {i+1}[^}}]*?image: "[^"]*"'
        replacement = f'id: {i+1}' + re.search(f'id: {i+1}([^}}]*?)image: "[^"]*"', content).group(1) + f'image: "{game["image"]}"'
        
        content = re.sub(pattern, replacement, content, count=1)
    
    # 保存文件
    with open('../src/pages/Home.tsx', 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ 封面图已更新！只改了图片，其他都没动")

if __name__ == "__main__":
    update_covers_only()

