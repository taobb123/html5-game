#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简单追加脚本：直接将爬虫数据追加到Home.tsx的games数组
"""

import json
import re
from pathlib import Path

def append_games_to_home():
    """直接将爬虫数据追加到Home.tsx"""
    
    # 读取爬虫数据
    with open('step1_homepage_games.json', 'r', encoding='utf-8') as f:
        step1_data = json.load(f)
    
    with open('step2_detailed_games.json', 'r', encoding='utf-8') as f:
        step2_data = json.load(f)
    
    # 创建URL映射
    step2_map = {}
    for game in step2_data.get('games', []):
        step2_map[game['url']] = game
    
    # 读取Home.tsx
    home_path = Path("../src/pages/Home.tsx")
    with open(home_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 找到games数组的结束位置
    games_end = content.find('];')
    if games_end == -1:
        print("❌ 未找到games数组")
        return
    
    # 生成新的游戏数据
    new_games = []
    for i, step1_game in enumerate(step1_data.get('games', [])):
        url = step1_game['url']
        step2_game = step2_map.get(url, {})
        
        game_code = f""",
    {{
      id: {i + 1},
      title: "{step1_game.get('title', '')}",
      image: "{step1_game.get('image', '')}",
      url: "{step1_game.get('url', '')}",
      iframe_url: "{step2_game.get('iframe_url', '')}",
      description: "{step2_game.get('description', '')[:200]}...",
      features: {json.dumps(step2_game.get('features', []), ensure_ascii=False)},
      category: "{step1_game.get('category', '')}",
      favorites: {step2_game.get('favorites', 0)},
      likes: {step2_game.get('likes', 0)},
      duration: "{step2_game.get('duration', '未知')}",
      play_count: {step2_game.get('play_count', 0)},
      tags: {json.dumps(step2_game.get('tags', []), ensure_ascii=False)},
      collected_at: "{step1_game.get('collected_at', '')}"
    }}"""
        
        new_games.append(game_code)
    
    # 在games数组结束前插入新游戏
    new_content = content[:games_end] + ''.join(new_games) + content[games_end:]
    
    # 保存文件
    with open(home_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"✅ 成功追加 {len(step1_data.get('games', []))} 个游戏到Home.tsx")

if __name__ == "__main__":
    append_games_to_home()

