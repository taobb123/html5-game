#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
安全数据更新脚本：确保不会破坏Home.tsx的数据结构
"""

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
import shutil
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SafeDataUpdater:
    """安全数据更新器"""
    
    def __init__(self, home_tsx_path: str = "../src/pages/Home.tsx"):
        self.home_tsx_path = Path(home_tsx_path)
        self.backup_path = self.home_tsx_path.with_suffix(f'.tsx.backup.{datetime.now().strftime("%Y%m%d-%H%M%S")}')
        
    def create_backup(self) -> bool:
        """创建安全备份"""
        try:
            if self.home_tsx_path.exists():
                shutil.copy2(self.home_tsx_path, self.backup_path)
                logger.info(f"✅ 安全备份已创建: {self.backup_path}")
                return True
            else:
                logger.error(f"❌ Home.tsx文件不存在: {self.home_tsx_path}")
                return False
        except Exception as e:
            logger.error(f"❌ 创建备份失败: {e}")
            return False
    
    def load_home_tsx(self) -> str:
        """安全加载Home.tsx文件"""
        try:
            with open(self.home_tsx_path, 'r', encoding='utf-8') as f:
                content = f.read()
            logger.info("✅ 成功加载Home.tsx文件")
            return content
        except Exception as e:
            logger.error(f"❌ 加载Home.tsx文件失败: {e}")
            return ""
    
    def analyze_structure(self, content: str) -> Dict[str, Any]:
        """分析Home.tsx的结构"""
        structure = {
            'has_games_array': False,
            'games_array_start': -1,
            'games_array_end': -1,
            'games_count': 0,
            'has_react_component': False,
            'component_start': -1,
            'component_end': -1
        }
        
        try:
            # 检查是否有games数组
            games_match = re.search(r'const\s+games\s*=\s*\[', content)
            if games_match:
                structure['has_games_array'] = True
                structure['games_array_start'] = games_match.start()
                
                # 找到games数组的结束位置
                bracket_count = 0
                in_string = False
                escape_next = False
                
                for i, char in enumerate(content[games_match.start():], games_match.start()):
                    if escape_next:
                        escape_next = False
                        continue
                    
                    if char == '\\':
                        escape_next = True
                        continue
                    
                    if char == '"' and not escape_next:
                        in_string = not in_string
                        continue
                    
                    if not in_string:
                        if char == '[':
                            bracket_count += 1
                        elif char == ']':
                            bracket_count -= 1
                            if bracket_count == 0:
                                structure['games_array_end'] = i + 1
                                break
            
            # 检查React组件结构
            component_match = re.search(r'export\s+default\s+function\s+Home', content)
            if component_match:
                structure['has_react_component'] = True
                structure['component_start'] = component_match.start()
                structure['component_end'] = len(content)
            
            # 计算games数量
            if structure['has_games_array']:
                games_section = content[structure['games_array_start']:structure['games_array_end']]
                structure['games_count'] = games_section.count('id:')
            
            logger.info(f"📊 结构分析完成:")
            logger.info(f"   - 有games数组: {structure['has_games_array']}")
            logger.info(f"   - games数量: {structure['games_count']}")
            logger.info(f"   - 有React组件: {structure['has_react_component']}")
            
            return structure
            
        except Exception as e:
            logger.error(f"❌ 结构分析失败: {e}")
            return structure
    
    def load_new_data(self, step1_file: str = "step1_homepage_games.json", 
                     step2_file: str = "step2_detailed_games.json") -> List[Dict[str, Any]]:
        """加载新的爬虫数据"""
        try:
            # 加载第一步数据
            with open(step1_file, 'r', encoding='utf-8') as f:
                step1_data = json.load(f)
            
            # 加载第二步数据
            with open(step2_file, 'r', encoding='utf-8') as f:
                step2_data = json.load(f)
            
            # 创建URL映射
            step2_map = {}
            for game in step2_data.get('games', []):
                step2_map[game['url']] = game
            
            # 合并数据
            merged_games = []
            for step1_game in step1_data.get('games', []):
                url = step1_game['url']
                step2_game = step2_map.get(url, {})
                
                merged_game = {
                    'id': len(merged_games) + 1,  # 重新分配ID
                    'title': step1_game.get('title', ''),
                    'image': step1_game.get('image', ''),
                    'url': step1_game.get('url', ''),
                    'iframe_url': step2_game.get('iframe_url', ''),
                    'description': step2_game.get('description', ''),
                    'features': step2_game.get('features', []),
                    'category': step1_game.get('category', ''),
                    'favorites': step2_game.get('favorites', 0),
                    'likes': step2_game.get('likes', 0),
                    'duration': step2_game.get('duration', ''),
                    'play_count': step2_game.get('play_count', 0),
                    'tags': step2_game.get('tags', []),
                    'collected_at': step1_game.get('collected_at', '')
                }
                
                merged_games.append(merged_game)
            
            logger.info(f"✅ 成功加载新数据: {len(merged_games)} 个游戏")
            return merged_games
            
        except Exception as e:
            logger.error(f"❌ 加载新数据失败: {e}")
            return []
    
    def generate_games_code(self, games: List[Dict[str, Any]]) -> str:
        """生成安全的games数组代码"""
        try:
            games_items = []
            
            for game in games:
                # 安全处理字符串
                title = self._escape_string(game.get('title', ''))
                description = self._escape_string(game.get('description', ''))
                image = self._escape_string(game.get('image', ''))
                url = self._escape_string(game.get('url', ''))
                iframe_url = self._escape_string(game.get('iframe_url', ''))
                category = self._escape_string(game.get('category', ''))
                duration = self._escape_string(game.get('duration', ''))
                collected_at = self._escape_string(game.get('collected_at', ''))
                
                # 处理数组
                features = json.dumps(game.get('features', []), ensure_ascii=False)
                tags = json.dumps(game.get('tags', []), ensure_ascii=False)
                
                # 处理数字
                favorites = game.get('favorites', 0)
                likes = game.get('likes', 0)
                play_count = game.get('play_count', 0)
                game_id = game.get('id', 1)
                
                game_item = f"""    {{
      id: {game_id},
      title: "{title}",
      image: "{image}",
      url: "{url}",
      iframe_url: "{iframe_url}",
      description: "{description}",
      features: {features},
      category: "{category}",
      favorites: {favorites},
      likes: {likes},
      duration: "{duration}",
      play_count: {play_count},
      tags: {tags},
      collected_at: "{collected_at}"
    }}"""
                
                games_items.append(game_item)
            
            # 返回完整的const games = [...]代码
            return f"const games = [\n{',\n'.join(games_items)}\n  ];"
            
        except Exception as e:
            logger.error(f"❌ 生成games代码失败: {e}")
            return "const games = [];"
    
    def _escape_string(self, text: str) -> str:
        """安全转义字符串"""
        if not text:
            return ""
        
        # 转义特殊字符
        text = text.replace('\\', '\\\\')
        text = text.replace('"', '\\"')
        text = text.replace('\n', '\\n')
        text = text.replace('\r', '\\r')
        text = text.replace('\t', '\\t')
        
        return text
    
    def safe_update_games(self, content: str, new_games: List[Dict[str, Any]]) -> str:
        """安全更新games数组"""
        try:
            # 分析现有结构
            structure = self.analyze_structure(content)
            
            if not structure['has_games_array']:
                logger.error("❌ 未找到games数组，无法安全更新")
                return content
            
            # 生成新的games代码
            new_games_code = self.generate_games_code(new_games)
            
            # 替换games数组
            old_games_section = content[structure['games_array_start']:structure['games_array_end']]
            new_content = content.replace(old_games_section, new_games_code)
            
            # 调试信息
            logger.info(f"🔍 原始games数组长度: {len(old_games_section)}")
            logger.info(f"🔍 新games数组长度: {len(new_games_code)}")
            logger.info(f"🔍 替换后内容长度: {len(new_content)}")
            logger.info(f"🔍 替换后包含'const games = [': {'const games = [' in new_content}")
            
            logger.info(f"✅ 安全更新games数组: {len(new_games)} 个游戏")
            return new_content
            
        except Exception as e:
            logger.error(f"❌ 安全更新失败: {e}")
            return content
    
    def save_home_tsx(self, content: str) -> bool:
        """安全保存Home.tsx文件"""
        try:
            with open(self.home_tsx_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info("✅ 安全保存Home.tsx文件")
            return True
        except Exception as e:
            logger.error(f"❌ 保存Home.tsx文件失败: {e}")
            return False
    
    def verify_update(self, content: str) -> bool:
        """验证更新是否成功"""
        try:
            # 调试信息
            logger.info(f"🔍 验证内容长度: {len(content)}")
            logger.info(f"🔍 包含'const games = [': {'const games = [' in content}")
            logger.info(f"🔍 包含'import React': {'import React' in content}")
            
            # 检查games数组是否存在
            if 'const games = [' not in content:
                logger.error("❌ 验证失败: games数组不存在")
                return False
            
            # 检查是否有游戏数据
            games_count = content.count('id:')
            logger.info(f"🔍 游戏数量: {games_count}")
            if games_count == 0:
                logger.error("❌ 验证失败: 没有游戏数据")
                return False
            
            # 检查基本的React结构（不强制要求export default function Home）
            if 'import React' not in content:
                logger.error("❌ 验证失败: React导入结构损坏")
                return False
            
            logger.info(f"✅ 验证成功: {games_count} 个游戏，结构完整")
            return True
            
        except Exception as e:
            logger.error(f"❌ 验证失败: {e}")
            return False
    
    def safe_update(self, step1_file: str = "step1_homepage_games.json", 
                   step2_file: str = "step2_detailed_games.json") -> bool:
        """执行安全更新"""
        try:
            logger.info("🛡️ 开始安全更新流程...")
            
            # 1. 创建备份
            if not self.create_backup():
                logger.error("❌ 备份创建失败，停止更新")
                return False
            
            # 2. 加载现有文件
            content = self.load_home_tsx()
            if not content:
                logger.error("❌ 文件加载失败，停止更新")
                return False
            
            # 3. 分析结构
            structure = self.analyze_structure(content)
            if not structure['has_games_array']:
                logger.error("❌ 未找到games数组，停止更新")
                return False
            
            # 4. 加载新数据
            new_games = self.load_new_data(step1_file, step2_file)
            if not new_games:
                logger.error("❌ 新数据加载失败，停止更新")
                return False
            
            # 5. 安全更新
            updated_content = self.safe_update_games(content, new_games)
            
            # 6. 验证更新
            if not self.verify_update(updated_content):
                logger.error("❌ 更新验证失败，停止保存")
                return False
            
            # 7. 保存文件
            if self.save_home_tsx(updated_content):
                logger.info("🎉 安全更新完成！")
                return True
            else:
                logger.error("❌ 文件保存失败")
                return False
                
        except Exception as e:
            logger.error(f"❌ 安全更新过程中出错: {e}")
            return False

def main():
    """主函数"""
    updater = SafeDataUpdater()
    
    # 执行安全更新
    success = updater.safe_update()
    
    if success:
        print("\n🎉 安全更新成功完成！")
        print("🛡️ 数据结构已保护")
        print("📁 备份文件已创建")
        print("✅ Home.tsx已安全更新")
    else:
        print("\n❌ 安全更新失败！")
        print("🛡️ 原始文件未修改")
        print("📁 请检查备份文件")

if __name__ == "__main__":
    main()
