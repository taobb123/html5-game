#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快速修复Home.tsx，确保页面正常显示
"""

def fix_home_tsx():
    """修复Home.tsx文件"""
    
    # 读取当前文件
    with open('../src/pages/Home.tsx', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 创建修复后的内容
    fixed_content = '''import React, { useState, useEffect } from 'react';
import { 
  ChevronRight,
  X,
  Maximize2,
  Minimize2,
  ChevronDown
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { getAllPosts } from '../blog-posts';

interface Game {
  id: number;
  title: string;
  image: string;
  description: string;
  features: string[];
  isNew: boolean;
  iframe: string;
  controls: { key: string; action: string }[];
  category?: string;
  playCount?: number;
  likes?: number;
  favorites?: number;
  duration?: string;
}

const games: Game[] = [
  {
    id: 1,
    title: "Grow A Garden - Growden.io",
    image: "https://imgs.crazygames.com/grow-a-garden---growden-io_16x9/20250902110117/grow-a-garden---growden-io_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    description: "Grow a Garden in Growden.io! In Growden.io, you can grow a garden of your dreams and unlock pets to help you grow a garden.",
    features: ["Garden Management", "Pet Collection", "Resource Management"],
    isNew: true,
    iframe: '<iframe src="https://idle-transport-tycoon-eqf.game-files.crazygames.com/unity/unity2020/idle-transport-tycoon-eqf.html?v=1.339" style="width: 100%; height: 100%;" frameborder="0" allow="gamepad *;"></iframe>',
    controls: [
      { key: "Mouse", action: "INTERACT" },
      { key: "Click", action: "PLANT" }
    ],
    category: "simulation",
    playCount: 20567,
    likes: 5509,
    duration: "15-30 分钟"
  },
  {
    id: 2,
    title: "Idle Transport Tycoon",
    image: "https://imgs.crazygames.com/idle-transport-tycoon-eqf_16x9/20250829043556/idle-transport-tycoon-eqf_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    description: "Idle Transport Tycoon is a strategic idle game that puts you in charge of building a thriving transport empire.",
    features: ["Strategic Management", "Global Expansion", "Idle Gameplay"],
    isNew: true,
    iframe: '<iframe src="https://idle-transport-tycoon-eqf.game-files.crazygames.com/unity/unity2020/idle-transport-tycoon-eqf.html?v=1.339" style="width: 100%; height: 100%;" frameborder="0" allow="gamepad *;"></iframe>',
    controls: [
      { key: "Mouse", action: "MANAGE" },
      { key: "Click", action: "UPGRADE" }
    ],
    category: "strategy",
    playCount: 4034,
    likes: 9218,
    duration: "5-10 分钟"
  },
  {
    id: 3,
    title: "Truck Hit Hero: Isekai Arena",
    image: "https://imgs.crazygames.com/truck-hit-hero-isekai-arena_16x9/20250828051212/truck-hit-hero-isekai-arena_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    description: "Truck-Hit Hero: Isekai Arena is a 2D RPG platformer inspired by classic isekai tales.",
    features: ["2D RPG Platformer", "Isekai Adventure", "Arena Battles"],
    isNew: true,
    iframe: '<iframe src="https://truck-hit-hero-isekai-arena.game-files.crazygames.com/unity/unity2020/truck-hit-hero-isekai-arena.html?v=1.0" style="width: 100%; height: 100%;" frameborder="0" allow="gamepad *;"></iframe>',
    controls: [
      { key: "Arrow Keys", action: "MOVE" },
      { key: "Space", action: "ATTACK" }
    ],
    category: "action",
    playCount: 7237,
    likes: 2052,
    duration: "10-15 分钟"
  }
];

function Home() {
  const [selectedGame, setSelectedGame] = useState<number | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showAllGames, setShowAllGames] = useState(false);

  const featuredGames = games.slice(0, 3);
  const displayedGames = showAllGames ? games : featuredGames;
  const blogPosts = getAllPosts().slice(0, 3);

  const selectedGameData = selectedGame ? games.find(game => game.id === selectedGame) : null;

  const handleFullscreen = () => {
    const gameContainer = document.getElementById('game-container');
    if (!gameContainer) return;

    if (!isFullscreen) {
      if (gameContainer.requestFullscreen) {
        gameContainer.requestFullscreen();
      } else if ((gameContainer as any).webkitRequestFullscreen) {
        (gameContainer as any).webkitRequestFullscreen();
      } else if ((gameContainer as any).msRequestFullscreen) {
        (gameContainer as any).msRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if ((document as any).webkitExitFullscreen) {
        (document as any).webkitExitFullscreen();
      } else if ((document as any).msExitFullscreen) {
        (document as any).msExitFullscreen();
      }
    }
  };

  React.useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Hero Section */}
      <section className="relative pt-16">
        <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent z-10" />
        <img
          src="https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=1600"
          alt="Hero"
          className="w-full h-[600px] object-cover"
        />
        <div className="absolute inset-0 flex items-center z-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-5xl md:text-7xl font-bold mb-4">
              Race to <span className="text-red-500">Glory</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-2xl">
              Experience the ultimate browser racing games. Choose your ride, customize your style, and dominate the streets.
            </p>
            <button 
              className="bg-red-500 hover:bg-red-600 px-8 py-3 rounded-full font-bold transition-colors"
              onClick={() => {
                const gamesSection = document.getElementById('games');
                gamesSection?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Play Now
            </button>
          </div>
        </div>
      </section>

      {/* Games Section */}
      <section id="games" className="py-20 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl font-bold">Our Games</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayedGames.map((game) => (
              <div key={game.id} className="bg-gray-900 rounded-lg overflow-hidden hover:transform hover:scale-105 transition-transform">
                <div className="relative">
                  <img src={game.image} alt={game.title} className="w-full h-48 object-cover" />
                  {game.isNew && (
                    <div className="absolute top-2 right-2">
                      <span className="bg-red-500 text-white px-2 py-1 rounded-full text-sm">
                        New
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <h3 className="text-xl font-bold ml-2">{game.title}</h3>
                  </div>
                  <p className="text-gray-400 mb-4">{game.description}</p>
                  <div className="mb-4">
                    <h4 className="font-bold mb-2">Key Features:</h4>
                    <ul className="list-disc list-inside text-gray-400">
                      {game.features.map((feature, index) => (
                        <li key={index}>{feature}</li>
                      ))}
                    </ul>
                  </div>
                  <button 
                    className="w-full bg-red-500 hover:bg-red-600 py-2 rounded-full font-bold transition-colors"
                    onClick={() => setSelectedGame(game.id)}
                  >
                    Play Now
                  </button>
                </div>
              </div>
            ))}
          </div>

          {!showAllGames && games.length > 3 && (
            <div className="flex justify-center mt-8">
              <button
                onClick={() => setShowAllGames(true)}
                className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full transition duration-200 flex items-center space-x-2"
              >
                <span>View More</span>
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Game Modal */}
      {selectedGame && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-75 flex items-center justify-center">
          <div className="bg-gray-800 w-full h-full max-w-7xl max-h-[90vh] rounded-lg overflow-hidden flex flex-col">
            <div className="flex justify-between items-center p-4 border-b border-gray-700">
              <h3 className="text-xl font-bold text-white">
                {selectedGameData?.title}
              </h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleFullscreen}
                  className="p-2 hover:bg-gray-700 rounded-lg transition-colors group relative"
                >
                  {isFullscreen ? (
                    <>
                      <Minimize2 className="w-5 h-5 text-gray-400 group-hover:text-white" />
                      <span className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap">
                        Exit Fullscreen
                      </span>
                    </>
                  ) : (
                    <>
                      <Maximize2 className="w-5 h-5 text-gray-400 group-hover:text-white" />
                      <span className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap">
                        Fullscreen
                      </span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => setSelectedGame(null)}
                  className="p-2 hover:bg-gray-700 rounded-lg transition-colors group relative"
                >
                  <X className="w-5 h-5 text-gray-400 group-hover:text-white" />
                  <span className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap">
                    Close
                  </span>
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto">
              <div id="game-container" className="relative w-full aspect-video">
                <div className="w-full h-full">
                  <div dangerouslySetInnerHTML={{ __html: selectedGameData?.iframe || '' }} className="w-full h-full" />
                </div>
              </div>

              <div className="p-6 bg-gray-900">
                <div className="mb-6">
                  <h4 className="text-xl font-bold mb-4">Controls:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {games[selectedGame - 1].controls.map((control, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="bg-gray-800 p-2 rounded">
                          <span className="text-gray-400">{control.key}</span>
                        </div>
                        <span className="text-gray-300">{control.action}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-xl font-bold mb-4">About {selectedGameData?.title}:</h4>
                  <p className="text-gray-300 leading-relaxed mb-4">
                    {selectedGameData?.description}
                  </p>
                  <div className="mt-4">
                    <h5 className="font-bold mb-2">Key Features:</h5>
                    <ul className="list-disc list-inside text-gray-300">
                      {selectedGameData?.features.map((feature, index) => (
                        <li key={index} className="mb-1">{feature}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Latest Blogs Section */}
      <section className="py-16 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-white">Latest Blogs</h2>
            <Link 
              to="/blog" 
              className="text-red-500 hover:text-red-400 flex items-center"
            >
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {blogPosts.map(post => (
              <Link 
                key={post.slug}
                to={`/blog/${post.slug}`}
                className="bg-gray-900 rounded-lg overflow-hidden hover:bg-gray-700 transition-colors"
              >
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="text-sm text-gray-400 mb-2">
                    {post.date} • {post.category}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{post.title}</h3>
                  <div className="flex items-center text-red-500 hover:text-red-400">
                    Read More <ChevronRight className="w-4 h-4 ml-1" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;'''
    
    # 保存修复后的文件
    with open('../src/pages/Home.tsx', 'w', encoding='utf-8') as f:
        f.write(fixed_content)
    
    print("✅ Home.tsx已修复！页面应该可以正常显示了")

if __name__ == "__main__":
    fix_home_tsx()

