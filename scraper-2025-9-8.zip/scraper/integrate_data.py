#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据集成脚本：将爬虫数据更新到Home.tsx
"""

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Any, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DataIntegrator:
    """数据集成器"""
    
    def __init__(self, home_tsx_path: str = "../src/pages/Home.tsx"):
        self.home_tsx_path = Path(home_tsx_path)
        self.backup_path = self.home_tsx_path.with_suffix('.tsx.backup')
    
    def load_step1_data(self, filename: str = "step1_homepage_games.json") -> Dict[str, Any]:
        """加载第一步数据"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            logger.info(f"成功加载第一步数据: {data.get('total_count', 0)} 个游戏")
            return data
        except Exception as e:
            logger.error(f"加载第一步数据失败: {e}")
            return {}
    
    def load_step2_data(self, filename: str = "step2_detailed_games.json") -> Dict[str, Any]:
        """加载第二步数据"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            logger.info(f"成功加载第二步数据: {data.get('total_count', 0)} 个游戏")
            return data
        except Exception as e:
            logger.error(f"加载第二步数据失败: {e}")
            return {}
    
    def merge_data(self, step1_data: Dict[str, Any], step2_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """合并两步数据"""
        merged_games = []
        
        # 创建第二步数据的URL映射
        step2_map = {}
        for game in step2_data.get('games', []):
            step2_map[game['url']] = game
        
        # 合并数据
        for step1_game in step1_data.get('games', []):
            url = step1_game['url']
            step2_game = step2_map.get(url, {})
            
            # 创建合并后的游戏数据
            merged_game = {
                # 从第一步获取的基本信息
                'title': step1_game.get('title', ''),
                'image': step1_game.get('image', ''),
                'url': step1_game.get('url', ''),
                'category': step1_game.get('category', ''),
                'collected_at': step1_game.get('collected_at', ''),
                
                # 从第二步获取的详细信息
                'iframe_url': step2_game.get('iframe_url', ''),
                'description': step2_game.get('description', ''),
                'features': step2_game.get('features', []),
                'favorites': step2_game.get('favorites', 0),
                'likes': step2_game.get('likes', 0),
                'duration': step2_game.get('duration', ''),
                'play_count': step2_game.get('play_count', 0),
                'tags': step2_game.get('tags', [])
            }
            
            merged_games.append(merged_game)
        
        logger.info(f"成功合并数据: {len(merged_games)} 个游戏")
        return merged_games
    
    def load_home_tsx(self) -> str:
        """加载Home.tsx文件内容"""
        try:
            with open(self.home_tsx_path, 'r', encoding='utf-8') as f:
                content = f.read()
            logger.info("成功加载Home.tsx文件")
            return content
        except Exception as e:
            logger.error(f"加载Home.tsx文件失败: {e}")
            return ""
    
    def create_backup(self, content: str) -> bool:
        """创建备份文件"""
        try:
            with open(self.backup_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info(f"已创建备份文件: {self.backup_path}")
            return True
        except Exception as e:
            logger.error(f"创建备份文件失败: {e}")
            return False
    
    def update_games_array(self, content: str, games: List[Dict[str, Any]]) -> str:
        """更新Home.tsx中的games数组"""
        try:
            # 生成新的games数组代码
            games_code = self._generate_games_code(games)
            
            # 查找并替换games数组
            pattern = r'const\s+games\s*=\s*\[.*?\];'
            replacement = f'const games = {games_code};'
            
            new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
            
            if new_content != content:
                logger.info("成功更新games数组")
                return new_content
            else:
                logger.warning("未找到games数组，尝试其他方法")
                return self._insert_games_array(content, games_code)
                
        except Exception as e:
            logger.error(f"更新games数组失败: {e}")
            return content
    
    def _generate_games_code(self, games: List[Dict[str, Any]]) -> str:
        """生成games数组的TypeScript代码"""
        games_items = []
        
        for game in games:
            # 处理字符串转义
            title = game.get('title', '').replace("'", "\\'").replace('"', '\\"')
            description = game.get('description', '').replace("'", "\\'").replace('"', '\\"')
            
            # 处理数组
            features = json.dumps(game.get('features', []), ensure_ascii=False)
            tags = json.dumps(game.get('tags', []), ensure_ascii=False)
            
            game_item = f"""    {{
      id: {len(games_items) + 1},
      title: "{title}",
      image: "{game.get('image', '')}",
      url: "{game.get('url', '')}",
      iframe_url: "{game.get('iframe_url', '')}",
      description: "{description}",
      features: {features},
      category: "{game.get('category', '')}",
      favorites: {game.get('favorites', 0)},
      likes: {game.get('likes', 0)},
      duration: "{game.get('duration', '')}",
      play_count: {game.get('play_count', 0)},
      tags: {tags},
      collected_at: "{game.get('collected_at', '')}"
    }}"""
            
            games_items.append(game_item)
        
        return f"[\n{',\n'.join(games_items)}\n  ]"
    
    def _insert_games_array(self, content: str, games_code: str) -> str:
        """在文件中插入games数组"""
        # 查找合适的位置插入games数组
        insert_patterns = [
            r'(import.*?from.*?;\s*\n)',
            r'(const.*?=.*?;\s*\n)',
            r'(export.*?function.*?Home.*?\{)'
        ]
        
        for pattern in insert_patterns:
            match = re.search(pattern, content, re.DOTALL)
            if match:
                insert_pos = match.end()
                new_content = content[:insert_pos] + f'\nconst games = {games_code};\n\n' + content[insert_pos:]
                logger.info("成功插入games数组")
                return new_content
        
        logger.error("无法找到合适的插入位置")
        return content
    
    def save_home_tsx(self, content: str) -> bool:
        """保存更新后的Home.tsx文件"""
        try:
            with open(self.home_tsx_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info("成功保存Home.tsx文件")
            return True
        except Exception as e:
            logger.error(f"保存Home.tsx文件失败: {e}")
            return False
    
    def integrate_data(self, step1_file: str = "step1_homepage_games.json", 
                      step2_file: str = "step2_detailed_games.json") -> bool:
        """执行完整的数据集成流程"""
        try:
            logger.info("开始数据集成流程...")
            
            # 1. 加载数据
            step1_data = self.load_step1_data(step1_file)
            step2_data = self.load_step2_data(step2_file)
            
            if not step1_data or not step2_data:
                logger.error("数据加载失败，无法继续集成")
                return False
            
            # 2. 合并数据
            merged_games = self.merge_data(step1_data, step2_data)
            if not merged_games:
                logger.error("数据合并失败，无法继续集成")
                return False
            
            # 3. 加载Home.tsx
            home_content = self.load_home_tsx()
            if not home_content:
                logger.error("无法加载Home.tsx文件")
                return False
            
            # 4. 创建备份
            if not self.create_backup(home_content):
                logger.warning("备份创建失败，但继续执行")
            
            # 5. 更新games数组
            updated_content = self.update_games_array(home_content, merged_games)
            
            # 6. 保存文件
            if self.save_home_tsx(updated_content):
                logger.info("✅ 数据集成完成！")
                return True
            else:
                logger.error("❌ 数据集成失败！")
                return False
                
        except Exception as e:
            logger.error(f"数据集成过程中出错: {e}")
            return False

def main():
    """主函数"""
    integrator = DataIntegrator()
    
    # 执行数据集成
    success = integrator.integrate_data()
    
    if success:
        print("🎉 数据集成成功完成！")
        print("📁 备份文件已保存")
        print("🔄 Home.tsx已更新")
    else:
        print("❌ 数据集成失败，请检查日志")

if __name__ == "__main__":
    main()

